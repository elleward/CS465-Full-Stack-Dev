const express = require('express'); // Express app
const router = express.Router(); // Router logic

// This is where we import the controllers we will use
const tripsController = require('../controllers/trips');

// define route for our trips endpoint
router
    .route('/trips')
    .get(tripsController.tripsList) // GET Method routes tripList
    .post(tripsController.tripsAddTrip); // POST Method Add a trip

    // GET Method routes tripsFindByCode - requires parameter
router
    .route('/trips/:tripCode')
    .get(tripsController.tripsFindByCode)
    .post(tripsController.tripsUpdateTrips);

module.exports = router;

