export const trips = [
  {
    "code": "GALR210214",
    "name": "Gale Reef",
    "length": "4 nights / 5 days",
    "start": "2021-02-14T08:00:00Z",
    "resort": "Emerald Bay, 3 stars",
    "perPerson": "799.00",
    "image": "reef1.jpg",
    "description": "<p>Gale Reef Sed et augue lorem. In sit amet placerat diam, id rhoncus lorem. Cras nec turpis ante. Donec sed felis risus. Nulla facilisi.</p>"
  },
  {
    "code": "DAWR210315",
    "name": "Dawson's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-03-15T08:00:00Z",
    "resort": "Blue Lagoon, 4 stars",
    "perPerson": "1199.00",
    "image": "reef2.jpg",
    "description": "<p>Dawson's Reef Integer magna leo, posuere et dignissim vitae, porttitor at odio. Pellentesque a metus nec magna placerat volutpat.</p>"
  },
  {
    "code": "CLAR210621",
    "name": "Claire's Reef",
    "length": "4 nights / 5 days",
    "start": "2021-06-21T08:00:00Z",
    "resort": "Coral Sands, 5 stars",
    "perPerson": "1999.00",
    "image": "reef3.jpg",
    "description": "<p>Claire's Reef Donec sed felis risus. Nulla facilisi. In libero nulla, fermentum ut pretium ac, pharetra et eros.</p>"
  }
];